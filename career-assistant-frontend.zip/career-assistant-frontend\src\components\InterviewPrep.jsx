// src/pages/InterviewPrep.jsx
import React from 'react';
import FeedbackCard from '../components/FeedbackCard';

const InterviewPrep = () => {
  return (
    <div className="p-6 max-w-3xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">🧠 Interview Feedback</h1>

      <FeedbackCard
        question="Tell me about yourself."
        answer="I am a 2nd-year CS student passionate about software development..."
        feedback="You spoke clearly and confidently. Try to structure your answer with education, projects, and goals."
        score={8}
      />

      <FeedbackCard
        question="What is a REST API?"
        answer="It allows communication between client and server using HTTP methods."
        feedback="Good definition! You can improve it by mentioning statelessness and resource-based architecture."
        score={9}
      />
    </div>
  );
};

export default InterviewPrep;
