// src/pages/JobListingPage.jsx (or any suitable name)
import JobCard from './JobListing'; // Keep the component you're importing
import { useEffect, useState } from "react";
import API from "../services/api";

const JobListingPage = () => {
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchJobs = async () => {
      try {
        const res = await API.get("/jobs/match");
        setJobs(res.data.jobs || []);
      } catch (err) {
        console.error(err);
        setError("Failed to fetch jobs.");
      } finally {
        setLoading(false);
      }
    };

    fetchJobs();
  }, []);

  if (loading) return <p className="text-center mt-10">Loading job recommendations...</p>;
  if (error) return <p className="text-center text-red-600 mt-10">{error}</p>;

  return (
    <div className="max-w-4xl mx-auto mt-10">
      <h2 className="text-3xl font-bold text-center mb-6 text-blue-700">Recommended Jobs</h2>
      
      {jobs.length === 0 ? (
        <p className="text-center text-gray-600">No matching jobs found.</p>
      ) : (
        <ul className="space-y-4">
          {jobs.map((job, index) => (
            <li
              key={index}
              className="p-4 bg-white rounded-lg shadow hover:shadow-lg transition"
            >
              <h3 className="text-xl font-semibold text-blue-600">{job.title}</h3>
              <p className="text-gray-700">{job.company} • {job.location}</p>
              {job.link && (
                <a
                  href={job.link}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-sm text-blue-500 hover:underline mt-2 inline-block"
                >
                  View Job →
                </a>
              )}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default JobListingPage;
