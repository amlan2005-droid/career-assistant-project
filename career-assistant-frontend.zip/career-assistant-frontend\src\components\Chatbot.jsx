import React, { useState } from 'react';

const ChatBot = () => {
  const [messages, setMessages] = useState([
    { sender: 'bot', text: 'Hi! I am your career assistant. How can I help you today?' }
  ]);
  const [input, setInput] = useState('');

  const handleSend = () => {
    if (input.trim() === '') return;

    // Add user message
    const newMessages = [...messages, { sender: 'user', text: input }];
    setMessages(newMessages);

    // Simulate bot reply (replace this with real API call later)
    setTimeout(() => {
      const reply = generateReply(input);
      setMessages([...newMessages, { sender: 'bot', text: reply }]);
    }, 600);

    setInput('');
  };

  const generateReply = (userMessage) => {
    // Dummy logic - Replace with API response
    if (userMessage.toLowerCase().includes('resume')) {
      return 'You can upload your resume on the dashboard and I’ll analyze it for you!';
    } else if (userMessage.toLowerCase().includes('job')) {
      return 'You can view personalized job recommendations in the Jobs tab.';
    } else {
      return 'That’s interesting! Let me look into that for you.';
    }
  };

  return (
    <div className="bg-white shadow-md rounded-2xl p-4 max-w-2xl mx-auto">
      <h2 className="text-xl font-bold mb-4 text-gray-800">💬 AI Career Assistant</h2>
      
      <div className="h-64 overflow-y-auto mb-4 p-2 bg-gray-50 rounded">
        {messages.map((msg, index) => (
          <div
            key={index}
            className={`mb-2 text-sm ${
              msg.sender === 'user' ? 'text-right' : 'text-left'
            }`}
          >
            <span
              className={`inline-block p-2 rounded-xl ${
                msg.sender === 'user'
                  ? 'bg-blue-100 text-blue-800'
                  : 'bg-gray-200 text-gray-800'
              }`}
            >
              {msg.text}
            </span>
          </div>
        ))}
      </div>

      <div className="flex gap-2">
        <input
          type="text"
          className="flex-1 border border-gray-300 rounded-lg p-2 text-sm"
          placeholder="Type your question..."
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
        />
        <button
          onClick={handleSend}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-blue-700"
        >
          Send
        </button>
      </div>
    </div>
  );
};

export default ChatBot;


