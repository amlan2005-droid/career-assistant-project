// src/services/api.js
import axios from "axios";

// Create an Axios instance with your backend base URL
const API = axios.create({
  baseURL: "http://127.0.0.1:8000", // Change if your backend runs on another host/port
});

// Optional: Automatically attach JWT token if logged in
API.interceptors.request.use((config) => {
  const token = localStorage.getItem("token"); // token saved during login
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export default API;
