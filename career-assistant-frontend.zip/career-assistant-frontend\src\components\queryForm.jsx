import { useState } from "react";
import API from "../services/api"; // Axios instance

const QueryForm = () => {
  const [query, setQuery] = useState("");
  const [response, setResponse] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!query.trim()) return;

    setLoading(true);
    setResponse("");

    try {
      const res = await API.post("/query", { question: query });
      setResponse(res.data.answer || "No response received.");
    } catch (err) {
      console.error("Error:", err);
      setResponse("Error: Failed to get a response.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto mt-10 p-6 bg-white rounded-xl shadow-md">
      <h2 className="text-2xl font-bold mb-4 text-blue-700 text-center">
        Ask Your Career Assistant
      </h2>

      <form onSubmit={handleSubmit} className="flex flex-col space-y-4">
        <textarea
          rows="4"
          className="p-3 border rounded resize-none"
          placeholder="Ask something like 'Suggest some remote jobs for me'..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        ></textarea>

        <button
          type="submit"
          className="bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700"
          disabled={loading}
        >
          {loading ? "Thinking..." : "Ask"}
        </button>
      </form>

      {response && (
        <div className="mt-6 p-4 bg-gray-100 border rounded text-gray-800 whitespace-pre-wrap">
          {response}
        </div>
      )}
    </div>
  );
};

export default QueryForm;
