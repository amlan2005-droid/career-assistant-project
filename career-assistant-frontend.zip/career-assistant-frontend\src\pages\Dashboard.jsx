import React from 'react';
import ChatBot from '../components/Chatbot';
import FeedbackCard from '../components/FeedbackCard';
import JobListing from '../components/JobListing';

const Dashboard = () => {
  return (
    <div className="p-6 max-w-6xl mx-auto space-y-8">
      <h1 className="text-3xl font-bold text-gray-800 mb-6">
        Welcome to Your Dashboard
      </h1>

      {/* Section: Interview Feedback */}
      <section>
        <h2 className="text-2xl font-semibold text-gray-700 mb-4">Interview Feedback</h2>
        <FeedbackCard
          question="Tell me about yourself."
          answer="I am a 2nd-year CS student passionate about software development..."
          feedback="You spoke clearly and confidently. Try to structure your answer with education, projects, and goals."
          score={8}
        />
        <FeedbackCard
          question="What is a REST API?"
          answer="It allows communication between client and server using HTTP methods."
          feedback="Good! Add more details about statelessness and HTTP verbs."
          score={9}
        />
      </section>

      {/* Section: Job Recommendations */}
      <section>
        <h2 className="text-2xl font-semibold text-gray-700 mb-4">📌 Recommended Jobs</h2>
        <div className="space-y-4">
          <JobListing
            title="Frontend Developer Intern"
            company="TechCorp"
            location="Remote"
            tags={['React', 'JavaScript', 'HTML/CSS']}
          />
          <JobListing
            title="Backend Developer Intern"
            company="InnovateX"
            location="Bangalore"
            tags={['Python', 'FastAPI', 'SQL']}
          />
        </div>
      </section>

      {/* Section: ChatBot */}
      <section>
        <h2 className="text-2xl font-semibold text-gray-700 mb-4">💬 Ask the Career Assistant</h2>
        <ChatBot />
      </section>
    </div>
  );
};

export default Dashboard;
